package be.ugent.psimoens.rxjavagemeente;

import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.jakewharton.rxbinding2.widget.RxTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {

    private static final String url = "http://users.ugent.be/~sleroux/postcodes.json";

    private TextInputEditText mGemeenteKiezer;
    private RecyclerView mGemeenteView;
    private List<Gemeente> mOrigData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mGemeenteView = (RecyclerView) findViewById(R.id.gemeenteView);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mGemeenteView.setLayoutManager(mLayoutManager);
        mGemeenteView.addItemDecoration(new DividerItemDecoration(mGemeenteView.getContext(), mLayoutManager.getOrientation()));

        mGemeenteKiezer = (TextInputEditText) findViewById(R.id.gemeenteKiezer);

        //download and parse JSON
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("response", response.toString());
                        Iterator<String> keys = response.keys();
                        try {
                            mOrigData = new ArrayList<Gemeente>();
                            while (keys.hasNext()) {
                                String key = keys.next();
                                JSONObject obj = response.getJSONObject(key);
                                mOrigData.add(new Gemeente(obj.getString("Postcode"),obj.getString("Gemeente"),obj.getString("Provincie")));
                            }
                            //sort alphabetically
                            Collections.sort(mOrigData, Comparator.comparing(Gemeente::getGemeenteNaam));
                            mGemeenteView.setAdapter(new GemeenteAdapter(mOrigData));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.i("response", error.toString());
                    }
                });
        queue.add(jsObjRequest);

        //todo create observable

    }


    protected class GemeenteViewHolder extends RecyclerView.ViewHolder {
        private TextView txtGemeente;
        private TextView txtProvincie;
        private TextView txtCode;

        public GemeenteViewHolder(View itemView) {
            super(itemView);
            txtCode = itemView.findViewById(R.id.txtcode);
            txtProvincie = itemView.findViewById(R.id.txtProvincie);
            txtGemeente = itemView.findViewById(R.id.txtGemeente);
        }

        public void setContent(Gemeente g) {
            txtCode.setText(g.postCode);
            txtGemeente.setText(g.gemeenteNaam);
            txtProvincie.setText(g.provincie);
        }
    }


    private class GemeenteAdapter extends RecyclerView.Adapter<GemeenteViewHolder> {
        private List<Gemeente> data;


        public GemeenteAdapter(List<Gemeente> data) {
            this.data = data;
        }

        @Override
        public GemeenteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            return new GemeenteViewHolder(layoutInflater.inflate(R.layout.gemeente_list_item, parent, false));
        }

        @Override
        public void onBindViewHolder(GemeenteViewHolder holder, int position) {
            holder.setContent(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }
    }

    private String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = this.getAssets().open("gemeentes.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            JSONObject jsonObject = new JSONObject(new String(buffer, "UTF-8"));
            System.out.println(jsonObject);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json;
    }

    private class Gemeente{
        String postCode;
        String gemeenteNaam;
        String provincie;

        public Gemeente(String postCode, String gemeenteNaam, String provincie){
            this.postCode = postCode;
            this.gemeenteNaam = gemeenteNaam;
            this.provincie = provincie;
        }

        public String getPostCode() { return postCode; }
        public String getGemeenteNaam() { return gemeenteNaam; }
        public String getProvincie() { return provincie; }
    }
}
