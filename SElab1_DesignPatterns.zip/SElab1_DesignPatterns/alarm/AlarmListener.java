package alarm;

public interface AlarmListener {
    
    public void alarm(Alarm alarm);
}
